﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19T1021188.BusinessLayers
{
    /// <summary>
    /// Loại tài khoản
    /// </summary>
    public enum AccountTypes
    {
        Employee,
        Customer
    }
}
