﻿namespace _19T1021188.DataLayers.SQLServer
{
    internal interface ICommonDAL
    {
    }
}